import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shapes3d.utils.*; 
import shapes3d.*; 
import shapes3d.ShapeGroup; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class skeletonV2 extends PApplet {







//tranformation vars for X-axis
float moveX = 0.0f;
float hipsX = 0.0f;
float spineX = 0.0f;
float spine1X = 0.0f;
float leftShoulderX = 0.0f;
float leftUpArmX = 0.0f;
float leftLowArmX = 0.0f;
float leftHandX = 0.0f;
float leftThumbX = 0.0f;
float rightShoulderX = 0.0f;
float rightUpArmX = 0.0f;
float rightLowArmX = 0.0f;
float rightHandX = 0.0f;
float rightThumbX = 0.0f;
float leftUpLegX = 0.0f;
float leftLowLegX = 0.0f;
float leftFootX = 0.0f;
float leftToeX = 0.0f;
float rightUpLegX = 0.0f;
float rightLowLegX = 0.0f;
float rightFootX = 0.0f;
float rightToeX = 0.0f;
float neckX = 0.0f;
float headX = 0.0f;


//tranformation vars for Y-axis
float moveY = 0.0f;
float hipsY = 0.0f;
float spineY = 0.0f;
float spine1Y = 0.0f;
float leftShoulderY = 0.0f;
float leftUpArmY = 0.0f;
float leftLowArmY = 0.0f;
float leftHandY = 0.0f;
float leftThumbY = 0.0f;
float rightShoulderY = 0.0f;
float rightUpArmY = 0.0f;
float rightLowArmY = 0.0f;
float rightHandY = 0.0f;
float rightThumbY = 0.0f;
float leftUpLegY = 0.0f;
float leftLowLegY = 0.0f;
float leftFootY = 0.0f;
float leftToeY = 0.0f;
float rightUpLegY = 0.0f;
float rightLowLegY = 0.0f;
float rightFootY = 0.0f;
float rightToeY = 0.0f;
float neckY = 0.0f;
float headY = 0.0f;


//tranformation vars for Z-axis
float moveZ = 0.0f;
float hipsZ = 0.0f;
float spineZ = 0.0f;
float spine1Z = 0.0f;
float leftShoulderZ = 0.0f;
float leftUpArmZ = 0.0f;
float leftLowArmZ = 0.0f;
float leftHandZ = 0.0f;
float leftThumbZ = 0.0f;
float rightShoulderZ = 0.0f;
float rightUpArmZ = 0.0f;
float rightLowArmZ = 0.0f;
float rightHandZ = 0.0f;
float rightThumbZ = 0.0f;
float leftUpLegZ = 0.0f;
float leftLowLegZ = 0.0f;
float leftFootZ = 0.0f;
float leftToeZ = 0.0f;
float rightUpLegZ = 0.0f;
float rightLowLegZ = 0.0f;
float rightFootZ = 0.0f;
float rightToeZ = 0.0f;
float neckZ = 0.0f;
float headZ = 0.0f;

//frame counter
int frame = 0;

//camera vars
float cameraWidth = -1000.0f;
float cameraDepth = -700.0f;
float cameraHeight = 0.0f;

float rotCamX = 0.0f;
float rotCamY = 0.0f;

//vars used to parse bvh
String[] test;
String[] translate;

int start = 0;
int frameNum;
String[] [] moveArray = new String[frameNum][78];

//selecting the mo cap file
String fileName;
String ffName;
boolean setUpDone = false;
boolean firstRun = false;

boolean showData = false;
boolean showInstructions = true;
//------------------------------------------
//Root Bone
//------------------------------------------
Box hips;

//------------------------------------------
//Spine
//------------------------------------------
Box spine;
Box spine1;

//------------------------------------------
//Left Arm
//------------------------------------------
Box leftShoulder;
Box leftUpArm;
Box leftLowArm;
Box leftHand;
Box leftThumb;

//------------------------------------------
//Right Arm
//------------------------------------------
Box rightShoulder;
Box rightUpArm;
Box rightLowArm;
Box rightHand;
Box rightThumb;

//------------------------------------------
//Left Leg
//------------------------------------------
Box leftUpLeg;
Box leftLowLeg;
Box leftFoot;
Box leftToe;

//------------------------------------------
//Left Leg
//------------------------------------------
Box rightUpLeg;
Box rightLowLeg;
Box rightFoot;
Box rightToe;

//------------------------------------------
//Head
//------------------------------------------
Box neck;
Ellipsoid head;
//to better visualize the head movement
Ellipsoid leftEye;
Ellipsoid rightEye;

Picked picked = null;

Box floor;



//set up function defines the defaults of the shapes/canvas
public void setup() {
  
  noFill();
  
  hips = new Box(73, 15, 10);
  hips.fill(randomColor());
  
  spine = new Box(10, 102.5f, 10);
  spine.fill(randomColor());
  
  spine1 = new Box(10, 78.3f, 10);
  spine1.fill(randomColor());
  
  leftShoulder = new Box(-67.1f, 15, 10);
  leftShoulder.fill(randomColor());
  
  rightShoulder = new Box(67.1f, 15, 10);
  rightShoulder.fill(randomColor());
  
  
  //define left arm
  leftUpArm = new Box(-109.4f, 10, 10);
  leftUpArm.fill(randomColor());
  leftLowArm = new Box(-85.2f, 10, 10);
  leftLowArm.fill(randomColor());
  leftHand = new Box(39.4f, 10, 10);
  leftHand.fill(randomColor());
  leftThumb = new Box(10, 10, 25);
  leftThumb.fill(randomColor());
  
  //define right arm
  rightUpArm = new Box(109.4f, 10, 10);
  rightUpArm.fill(randomColor());
  rightLowArm = new Box(85.2f, 10, 10);
  rightLowArm.fill(randomColor());
  rightHand = new Box(39.4f, 10, 10);
  rightHand.fill(randomColor());
  rightThumb = new Box(10, 10, 25);
  rightThumb.fill(randomColor());
  
  //define left leg
  leftUpLeg = new Box(10, -157.1f, 10);
  leftUpLeg.fill(randomColor());
  leftLowLeg = new Box(10, -154.2f, 10);
  leftLowLeg.fill(randomColor()); 
  
  //define right leg
  rightUpLeg = new Box(10, -157.1f, 10);
  rightUpLeg.fill(randomColor());
  rightLowLeg = new Box(10, -154.2f, 10);
  rightLowLeg.fill(randomColor());
  
  //define left foot
  leftFoot = new Box(20, 59.3f, 10);
  leftFoot.fill(randomColor());
  leftToe = new Box(20, 10, 29.5f);
  leftToe.fill(randomColor());
  
  //define right foot
  rightFoot = new Box(20, 59.3f, 10);
  rightFoot.fill(randomColor());
  rightToe = new Box(20, 10, 29.5f);
  rightToe.fill(randomColor());
  
  //define the head
  neck = new Box(10, 69.1f, 10);
  neck.fill(randomColor());
  head = new Ellipsoid(40, 30, 30);
  head.fill(randomColor());
  leftEye =  new Ellipsoid(10, 15, 5);
  int eyes = randomColor(); //makes both eyes the same colour
  leftEye.fill(eyes);
  rightEye =  new Ellipsoid(10, 15, 5);
  rightEye.fill(eyes);
  
  //define floor
  floor = new Box(5000, 1, 1500);
  
  selectInput("Select a file to process:", "fileSelected"); //promts user to select a motion file

}


//draws the shapes and applies the transformations/translations
public void draw() {
  background(0);
  
  if (setUpDone == true){  //checks if a .bvh file is selected
    
    if (firstRun == true){  //on first iteration, sets moveArray;
      //=======================================================================
      //PARSE BVH FILE
      //=======================================================================
        test = loadStrings(fileName); //change file name to play different animations
       
       String[] fName = split(fileName, '\\');
       ffName = fName[fName.length-1];
       println(ffName);
        //finds the start of the motion data, dumps it into a list
        //also finds the number of frames in the animation
        for (int i = 0; i < test.length; i++) {
         if (test[i].equals("MOTION")){
           start = i + 3;
           String [] frames = split(test[i+1], ' ');
           frameNum = PApplet.parseInt(frames[1]);
           break;
         }
        }
  
        moveArray = new String[frameNum][78];
        
        //splits the motion data by bone and stores it in the move array for later use
        for (int k = 0; k < (test.length)-start; k++){
          translate = split(test[start+k], ' ');
          int tranSize = 78;
          for (int j = 0; j < tranSize; j++){
            moveArray[k][j] = translate[j];
          }
        }
        firstRun = false;
    }
    
    getNextFrame();  //finds the next values for animation matrix
    keyPressedIsCheckedContinuusly();  //pulls values for the camera movement
    
    
  
  
  //=======================================================================
  //ANIMATION MATRICIES
  //=======================================================================
    pushMatrix();
      translate(width + cameraWidth, height + cameraHeight, cameraDepth);
      //affects the entire skeleton as is is before any object is drawn
      rotateX(rotCamX);
      rotateY(rotCamY + 3.14159f);
      floor.draw(getGraphics());
    
      //------------------------------------------
      //Spine --> Head
      //------------------------------------------
      pushMatrix();
        translate(-moveX*10, -moveY*10, -moveZ*10);
        rotateX(radians(hipsX));
        rotateY(radians(hipsY));
        rotateZ(radians(hipsZ));
        hips.draw(getGraphics());
        pushMatrix();
          translate(0, -7.5f, 0);
          rotateX(radians(spineX));
          rotateY(radians(spineY));
          rotateZ(radians(spineZ));
          translate(0, -51.25f, 0);
          spine.draw(getGraphics());
          pushMatrix();
            translate(0, -51.25f, 0);
            rotateX(radians(spine1X));
            rotateY(radians(spine1Y));
            rotateZ(radians(spine1Z));
            translate(0, -39.15f, 0);
            spine1.draw(getGraphics());
            pushMatrix();
              translate(0, -39.15f, 0);
              rotateX(radians(neckX));
              rotateY(radians(neckY));
              rotateZ(radians(neckZ));
              translate(0, -34.55f, 0);
              neck.draw(getGraphics());
              pushMatrix();
                translate(0, -34.55f, 0);
                rotateX(radians(headX));
                rotateY(radians(headY));
                rotateZ(radians(headZ));
                head.draw(getGraphics());
                translate(15, -5, -30);
                leftEye.draw(getGraphics());
                translate(-30, 0, 0);
                rightEye.draw(getGraphics());
              popMatrix();
            popMatrix();
            
            
      //------------------------------------------
      //Left Arm
      //------------------------------------------
            pushMatrix();
              translate(-5, -39.15f, 0);
              rotateX(radians(leftShoulderX));
              rotateY(radians(leftShoulderY));
              rotateZ(radians(leftShoulderZ));
              translate(-33.55f, 0, 0);
              leftShoulder.draw(getGraphics());
              pushMatrix();
                translate(-33.55f, 0, 0);
                rotateX(radians(leftUpArmX));
                rotateY(radians(leftUpArmY));
                rotateZ(radians(leftUpArmZ));
                translate(-54.7f, 0, 0);
                leftUpArm.draw(getGraphics());
                pushMatrix();
                  translate(-54.7f, 0, 0);
                  rotateX(radians(leftLowArmX));
                  rotateY(radians(leftLowArmY));
                  rotateZ(radians(leftLowArmZ));
                  translate(-42.6f, 0, 0);
                  leftLowArm.draw(getGraphics());
                  pushMatrix();
                    translate(-42.6f, 0, 0);
                    rotateX(radians(leftHandX));
                    rotateY(radians(leftHandY));
                    rotateZ(radians(leftHandZ));
                    translate(-19.75f, 0, 0);
                    leftHand.draw(getGraphics());
                  popMatrix();
                  pushMatrix();
                    translate(-42.6f, 0, -2.5f);
                    rotateX(radians(leftThumbX));
                    rotateY(radians(leftThumbY));
                    rotateZ(radians(leftThumbZ));
                    translate(0, 0, -12.5f);
                    leftThumb.draw(getGraphics());
                  popMatrix();
                popMatrix();
              popMatrix();
            popMatrix();
            
            
      //------------------------------------------
      //Right Arm
      //------------------------------------------
            pushMatrix();
              translate(5, -39.15f, 0);
              rotateX(radians(rightShoulderX));
              rotateY(radians(rightShoulderY));
              rotateZ(radians(rightShoulderZ));
              translate(33.55f, 0, 0);
              rightShoulder.draw(getGraphics());
              pushMatrix();
                translate(33.55f, 0, 0);
                rotateX(radians(rightUpArmX));
                rotateY(radians(rightUpArmY));
                rotateZ(radians(rightUpArmZ));
                translate(54.7f, 0, 0);
                rightUpArm.draw(getGraphics());
                pushMatrix();
                  translate(54.7f, 0, 0);
                  rotateX(radians(rightLowArmX));
                  rotateY(radians(rightLowArmY));
                  rotateZ(radians(rightLowArmZ));
                  translate(42.6f, 0, 0);
                  rightLowArm.draw(getGraphics());
                  pushMatrix();
                    translate(42.6f, 0, 0);
                    rotateX(radians(rightHandX));
                    rotateY(radians(rightHandY));
                    rotateZ(radians(rightHandZ));
                    translate(19.75f, 0, 0);
                    rightHand.draw(getGraphics());
                  popMatrix();
                  pushMatrix();
                    translate(42.6f, 0, -2.5f);
                    rotateX(radians(rightThumbX));
                    rotateY(radians(rightThumbY));
                    rotateZ(radians(rightThumbZ));
                    translate(0, 0, -12.5f);
                    rightThumb.draw(getGraphics());
                  popMatrix();
                popMatrix();
              popMatrix();
            popMatrix();  
          popMatrix();
        popMatrix();
      
      
      //------------------------------------------
      //Left Leg
      //------------------------------------------ 
        pushMatrix();
          translate(-36.5f, 0, 0);
          translate(0, 7.5f, 0);
          rotateX(radians(leftUpLegX));
          rotateY(radians(leftUpLegY));
          rotateZ(radians(leftUpLegZ));
          translate(0, 78.55f, 0);
          leftUpLeg.draw(getGraphics());
          pushMatrix();
            translate(0, 78.55f, 0);
            rotateX(radians(leftLowLegX));
            rotateY(radians(leftLowLegY));
            rotateZ(radians(leftLowLegZ));
            translate(0, 77.1f, 0);
            leftLowLeg.draw(getGraphics());
            pushMatrix();
              translate(0, 77.1f, 0);
              rotateX(radians(leftFootX));
              rotateY(radians(leftFootY));
              rotateZ(radians(leftFootZ));
              rotateX(-1.309f);
              translate(0, 29.65f, 0);
              leftFoot.draw(getGraphics());
            popMatrix();
          popMatrix();
        popMatrix();
              
              
      //------------------------------------------
      //Right Leg
      //------------------------------------------   
        pushMatrix();
          translate(36.5f, 0, 0);
          translate(0, 7.5f, 0);
          rotateX(radians(rightUpLegX));
          rotateY(radians(rightUpLegY));
          rotateZ(radians(rightUpLegZ));
          translate(0, 78.55f, 0);
          rightUpLeg.draw(getGraphics());
          pushMatrix();
            translate(0, 78.55f, 0);
            rotateX(radians(rightLowLegX));
            rotateY(radians(rightLowLegY));
            rotateZ(radians(rightLowLegZ));
            translate(0, 77.1f, 0);
            rightLowLeg.draw(getGraphics());
            pushMatrix();
              translate(0, 77.1f, 0);
              rotateX(radians(rightFootX));
              rotateY(radians(rightFootY));
              rotateZ(radians(rightFootZ));
              rotateX(-1.309f);
              translate(0, 29.65f, 0);
              rightFoot.draw(getGraphics());
            popMatrix();
          popMatrix();
        popMatrix();
      popMatrix();
    popMatrix(); //closes the one way up top
  }
} 

//=======================================================================
//CONTROLS AND CONSTRAINTS
//=======================================================================
public void getNextFrame() {
  moveX = PApplet.parseFloat(moveArray[frame][1]);
  moveY = PApplet.parseFloat(moveArray[frame][2]);
  moveZ = PApplet.parseFloat(moveArray[frame][3]);
  
  hipsX = PApplet.parseFloat(moveArray[frame][4]);
  hipsY = PApplet.parseFloat(moveArray[frame][5]);
  hipsZ = PApplet.parseFloat(moveArray[frame][6]);
  
  leftUpLegX = PApplet.parseFloat(moveArray[frame][7]);
  leftUpLegY = PApplet.parseFloat(moveArray[frame][8]);
  leftUpLegZ = PApplet.parseFloat(moveArray[frame][9]);
   
  leftLowLegX = PApplet.parseFloat(moveArray[frame][10]);
  leftLowLegY = PApplet.parseFloat(moveArray[frame][11]);
  leftLowLegZ = PApplet.parseFloat(moveArray[frame][12]);
   
  leftFootX = PApplet.parseFloat(moveArray[frame][13]);
  leftFootY = PApplet.parseFloat(moveArray[frame][14]);
  leftFootZ = PApplet.parseFloat(moveArray[frame][15]);
   
  leftToeX = PApplet.parseFloat(moveArray[frame][16]);
  leftToeY = PApplet.parseFloat(moveArray[frame][17]);
  leftToeZ = PApplet.parseFloat(moveArray[frame][18]);
   
  rightUpLegX = PApplet.parseFloat(moveArray[frame][19]);
  rightUpLegY = PApplet.parseFloat(moveArray[frame][20]);
  rightUpLegZ = PApplet.parseFloat(moveArray[frame][21]);
   
  rightLowLegX = PApplet.parseFloat(moveArray[frame][22]);
  rightLowLegY = PApplet.parseFloat(moveArray[frame][23]);
  rightLowLegZ = PApplet.parseFloat(moveArray[frame][24]);
   
  rightFootX = PApplet.parseFloat(moveArray[frame][25]);
  rightFootY = PApplet.parseFloat(moveArray[frame][26]);
  rightFootZ = PApplet.parseFloat(moveArray[frame][27]);
   
  rightToeX = PApplet.parseFloat(moveArray[frame][28]);
  rightToeY = PApplet.parseFloat(moveArray[frame][29]);
  rightToeZ = PApplet.parseFloat(moveArray[frame][30]);
   
  spineX = PApplet.parseFloat(moveArray[frame][31]);
  spineY = PApplet.parseFloat(moveArray[frame][32]);
  spineZ = PApplet.parseFloat(moveArray[frame][33]);
   
  spine1X = PApplet.parseFloat(moveArray[frame][34]);
  spine1Y = PApplet.parseFloat(moveArray[frame][35]);
  spine1Z = PApplet.parseFloat(moveArray[frame][36]);
   
  neckX = PApplet.parseFloat(moveArray[frame][37]);
  neckY = PApplet.parseFloat(moveArray[frame][38]);
  neckZ = PApplet.parseFloat(moveArray[frame][39]);
   
  headX = PApplet.parseFloat(moveArray[frame][40]);
  headY = PApplet.parseFloat(moveArray[frame][41]);
  headZ = PApplet.parseFloat(moveArray[frame][42]);
  
  leftShoulderX = PApplet.parseFloat(moveArray[frame][43]);
  leftShoulderY = PApplet.parseFloat(moveArray[frame][44]);
  leftShoulderZ = PApplet.parseFloat(moveArray[frame][45]);
  
  leftUpArmX = PApplet.parseFloat(moveArray[frame][46]);
  leftUpArmY = PApplet.parseFloat(moveArray[frame][47]);
  leftUpArmZ = PApplet.parseFloat(moveArray[frame][48]);
  
  leftLowArmX = PApplet.parseFloat(moveArray[frame][49]);
  leftLowArmY = PApplet.parseFloat(moveArray[frame][50]);
  leftLowArmZ = PApplet.parseFloat(moveArray[frame][51]);
  
  leftHandX = PApplet.parseFloat(moveArray[frame][52]);
  leftHandY = PApplet.parseFloat(moveArray[frame][53]);
  leftHandZ = PApplet.parseFloat(moveArray[frame][54]);
  
  leftThumbX = PApplet.parseFloat(moveArray[frame][58]);
  leftThumbY = PApplet.parseFloat(moveArray[frame][59]);
  leftThumbZ = PApplet.parseFloat(moveArray[frame][60]);
  
  rightShoulderX = PApplet.parseFloat(moveArray[frame][61]);
  rightShoulderY = PApplet.parseFloat(moveArray[frame][62]);
  rightShoulderZ = PApplet.parseFloat(moveArray[frame][63]);
  
  rightUpArmX = PApplet.parseFloat(moveArray[frame][64]);
  rightUpArmY = PApplet.parseFloat(moveArray[frame][65]);
  rightUpArmZ = PApplet.parseFloat(moveArray[frame][66]);
  
  rightLowArmX = PApplet.parseFloat(moveArray[frame][67]);
  rightLowArmY = PApplet.parseFloat(moveArray[frame][68]);
  rightLowArmZ = PApplet.parseFloat(moveArray[frame][69]);
  
  rightHandX = PApplet.parseFloat(moveArray[frame][70]);
  rightHandY = PApplet.parseFloat(moveArray[frame][71]);
  rightHandZ = PApplet.parseFloat(moveArray[frame][72]);
  
  rightThumbX = PApplet.parseFloat(moveArray[frame][76]);
  rightThumbY = PApplet.parseFloat(moveArray[frame][77]);
  rightThumbZ = PApplet.parseFloat(moveArray[frame][77]);
  
  
  if (frame < frameNum-1){  //iterate
    frame += 1;  
  } else frame = 0;  //and then loop
  
  if (showData == true){
    textSize(32);
    fill(255,255,255);
    text("File:", 10, 30);
    fill(255,0,0);
    text(ffName, 85, 30);
    fill(255,255,255);
    text("Frame: " + frame + "/" + frameNum, 10, 62);
    text("Hips(Translation): (" + nf(moveX, 0, 2) + ", " + nf(moveY, 0, 2) + ", " + nf(moveZ, 0, 2) + ")", 10, 30+(32*2));
    text("Hips(Rotation): (" + nf(hipsX, 0, 2) + ", " + nf(hipsY, 0, 2) + ", " + nf(hipsZ, 0, 2) + ")", 10, 30+(32*3));
    text("Left Upper Leg: (" + nf(leftUpLegX, 0, 2) + ", " + nf(leftUpLegY, 0, 2) + ", " + nf(leftUpLegZ, 0, 2) + ")", 10, 30+(32*4));
    text("Left Lower Leg: (" + nf(leftLowLegX, 0, 2) + ", " + nf(leftLowLegY, 0, 2) + ", " + nf(leftLowLegZ, 0, 2) + ")", 10, 30+(32*5));
    text("Left Foot: (" + nf(leftFootX, 0, 2) + ", " + nf(leftFootY, 0, 2) + ", " + nf(leftFootZ, 0, 2) + ")", 10, 30+(32*6));
    text("Right Upper Leg: (" + nf(rightUpLegX, 0, 2) + ", " + nf(rightUpLegY, 0, 2) + ", " + nf(rightUpLegZ, 0, 2) + ")", 10, 30+(32*7));
    text("Right Lower Leg: (" + nf(rightLowLegX, 0, 2) + ", " + nf(rightLowLegY, 0, 2) + ", " + nf(rightLowLegZ, 0, 2) + ")", 10, 30+(32*8));
    text("Right Foot: (" + nf(rightFootX, 0, 2) + ", " + nf(rightFootY, 0, 2) + ", " + nf(rightFootZ, 0, 2) + ")", 10, 30+(32*9));
    text("Lower Spine: (" + nf(spineX, 0, 2) + ", " + nf(spineY, 0, 2) + ", " + nf(spineZ, 0, 2) + ")", 10, 30+(32*10));
    text("Upper Spine: (" + nf(spine1X, 0, 2) + ", " + nf(spine1Y, 0, 2) + ", " + nf(spine1Z, 0, 2) + ")", 10, 30+(32*11));
    text("Neck: (" + nf(neckX, 0, 2) + ", " + nf(neckY, 0, 2) + ", " + nf(neckZ, 0, 2) + ")", 10, 30+(32*12));
    text("Head: (" + nf(headX, 0, 2) + ", " + nf(headY, 0, 2) + ", " + nf(headZ, 0, 2) + ")", 10, 30+(32*13));
    text("Left Shoulder: (" + nf(leftShoulderX, 0, 2) + ", " + nf(leftShoulderY, 0, 2) + ", " + nf(leftShoulderZ, 0, 2) + ")", 10, 30+(32*14));
    text("Left Upper Arm: (" + nf(leftUpArmX, 0, 2) + ", " + nf(leftUpArmY, 0, 2) + ", " + nf(leftUpArmZ, 0, 2) + ")", 10, 30+(32*15));
    text("Left Lower Arm: (" + nf(leftLowArmX, 0, 2) + ", " + nf(leftLowArmY, 0, 2) + ", " + nf(leftLowArmZ, 0, 2) + ")", 10, 30+(32*16));
    text("Left Hand: (" + nf(leftHandX, 0, 2) + ", " + nf(leftHandY, 0, 2) + ", " + nf(leftHandZ, 0, 2) + ")", 10, 30+(32*17));
    text("Right Shoulder: (" + nf(rightShoulderX, 0, 2) + ", " + nf(rightShoulderY, 0, 2) + ", " + nf(rightShoulderZ, 0, 2) + ")", 10, 30+(32*18));
    text("Right Upper Arm: (" + nf(rightUpArmX, 0, 2) + ", " + nf(rightUpArmY, 0, 2) + ", " + nf(rightUpArmZ, 0, 2) + ")", 10, 30+(32*19));
    text("Right Lower Arm: (" + nf(rightLowArmX, 0, 2) + ", " + nf(rightLowArmY, 0, 2) + ", " + nf(rightLowArmZ, 0, 2) + ")", 10, 30+(32*20));
    text("Right Hand: (" + nf(rightHandX, 0, 2) + ", " + nf(rightHandY, 0, 2) + ", " + nf(rightHandZ, 0, 2) + ")", 10, 30+(32*21));
  }
  
  if (showInstructions == true){
    textSize(32);
    fill(255,255,255);
    text("Press 1 to hide instructions", 10, 30);
    text("Press 2 to show data", 10, 62);
    text("Press 3 to load a new file", 10, 94);
  }
}
  
//=======================================================================
//CONTROLS AND CONSTRAINTS
//=======================================================================
public void keyPressedIsCheckedContinuusly() {
  if (keyPressed) {
    if ((key == 'w')||(key == 'W')){
        cameraDepth += 10;
    }
    if ((key == 's')||(key == 'S')){
        cameraDepth -= 10;
    }
    if ((key == 'a')||(key == 'A')){
        rotCamY += 0.01f;
    }
    if ((key == 'd')||(key == 'D')){
        rotCamY -= 0.01f;
    }
  }
}

public void keyReleased() {
  if (key == '2'){  //toggle the data (frame number, file name, etc)
      if (showData == false){
        showData = true;
        showInstructions = false;
      } else if (showData == true){
        showData = false;
        showInstructions = false;
      }
    }
    if (key == '3'){  //press to load a new file
      selectInput("Select a file to process:", "fileSelected"); //promts user to select a motion file
      firstRun = false;
      setUpDone = false;
    }
    if (key == '1'){  //toggle instructions
      if (showInstructions == false){
        showInstructions = true;
        showData = false;
      } else if (showInstructions == true){
        showInstructions = false;
        showData = false;
      }
    }
}

//=======================================================================
//SELECT RANDOM COLOUR
//=======================================================================
public int randomColor(){
  return color(random(0,255), random(0,255), random(0,255));
}


//=======================================================================
//DEFINE THE INPUT FILE PATH
//=======================================================================
public void fileSelected(File selection) {
  if (selection == null) {
    //println("Window was closed or the user hit cancel.");
  } else {
    //println("User selected " + selection.getPath());
    fileName = selection.getPath();
    setUpDone = true;
    firstRun = true;
    frame = 0;
  }
}
  public void settings() {  fullScreen(P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "skeletonV2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
